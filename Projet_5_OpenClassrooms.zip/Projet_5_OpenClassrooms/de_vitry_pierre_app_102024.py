import gradio as gr
import tensorflow as tf
import numpy as np
from PIL import Image

# Chargement du meilleur modèle
model_path = r'C:\Users\pdevi\OneDrive\Desktop\OpenClassrooms\Projet_5\best_model_finetuned.keras'
model = tf.keras.models.load_model(model_path)

# Noms des classes correspondant aux races de chiens
dog_races = ['Chihuahua', 'Japanese_spaniel', 'Maltese_dog']

# Taille d'image attendue par le modèle
img_size = 265

def classify_image(img):
    # Convertir l'image téléchargée au format correct
    img = img.resize((img_size, img_size))
    img_array = np.array(img) / 265.0  # Normaliser l'image

    # Vérifier si l'image est en RGB ou en niveaux de gris (si le modèle attend une image en niveaux de gris)
    if len(img_array.shape) == 2:  # Image en niveaux de gris
        img_array = np.expand_dims(img_array, axis=-1)  # Ajouter une dimension pour les niveaux de gris

    img_array = np.expand_dims(img_array, axis=0)  # Ajouter une dimension pour le batch

    # Prédire la race du chien
    predictions = model.predict(img_array)
    predicted_class = np.argmax(predictions, axis=1)[0]  # Trouver la classe avec la probabilité la plus élevée
    breed = dog_races[predicted_class]  # Obtenir le nom de la race prédite

    return f"Ce chien ressemble à un {breed} !"

# Interface Gradio
gr.Interface(
    fn=classify_image,
    inputs=gr.Image(type="pil"),  # Permettre aux utilisateurs de télécharger des images
    outputs="text",  # Afficher le résultat de la classification sous forme de texte
    title="Classificateur de races de chiens",
    description="Téléchargez une image d'un chien, et le modèle classera sa race."
).launch()
